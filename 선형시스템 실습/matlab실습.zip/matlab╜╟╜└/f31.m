function y = f31(x)
y=1./(1+8*x.^2);