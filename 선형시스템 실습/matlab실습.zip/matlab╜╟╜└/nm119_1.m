%nm119_1: example of if-end block
t = 0;
if t > 0
sgnt = 1;
else
sgnt = -1;
end