%nm119_2: example of if-elseif-end block
t=-3;
if t > 0
sgnt = 1
elseif t < 0
sgnt = -1
end