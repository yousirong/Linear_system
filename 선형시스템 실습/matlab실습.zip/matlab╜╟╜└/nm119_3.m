%nm119_3: example of if-elseif-else-end block
t=1;
if t > 0, sgnt = 1
elseif t<0, sgnt = -1
else sgnt = 0
end