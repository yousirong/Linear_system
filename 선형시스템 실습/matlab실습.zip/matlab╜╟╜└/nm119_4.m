point = 85;
 if point >= 90, grade = 'A' 
 elseif point >= 80, grade = 'B'
 elseif point >= 70, grade = 'C' 
 elseif point >= 60, grade = 'D' 
 else grade = 'F' 
end